const appointments = {
    "2023-07-10": "full",
    "2023-07-11": "empty",
    "2023-07-12": "empty",
    "2023-07-13": "full",
    "2023-07-14": "empty",
};

const calendarBody = document.getElementById("calendarBody");

const generateCalendar = () => {
    const month = 6; 
    const year = 2024;
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const firstDay = new Date(year, month, 1).getDay();
    
    let html = "";
    let day = 1;

    for (let row = 0; row < 6; row++) {
        html += "<tr>";
        for (let col = 0; col < 7; col++) {
            if (row === 0 && col < firstDay) {
                html += "<td class='empty'></td>";
            } else if (day > daysInMonth) {
                html += "<td class='empty'></td>";
            } else {
                const currentDate = `${year}-${month + 1}-${day < 10 ? '0' + day : day}`;
                if (col === 3) { 
                    html += `<td class='closed'>${day}</td>`;
                } else {
                    html += `<td onclick="checkAvailability('${currentDate}')">${day}</td>`;
                }
                day++;
            }
        }
        html += "</tr>";
    }
    
    calendarBody.innerHTML = html;
};

function checkAvailability(date) {
    const availabilityDiv = document.getElementById("availability");
    
    if (appointments[date]) {
        if (appointments[date] === "full") {
            availabilityDiv.innerHTML = `<p style="color: red;">No slots available on ${date}.</p>`;
        } else {
            window.location.href = `slot.html?date=${date}`;
        }
    } else {
        availabilityDiv.innerHTML = `<p style="color: blue;">No appointments scheduled on ${date}.  <a href="slot.html">Click here</a></p>`;
    }
}

generateCalendar();
